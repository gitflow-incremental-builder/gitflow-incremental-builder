This directory is ignored by Git to freely make adjustments (without breaking the diff based tests).

Dependening on which mode to test (GIB directly as an extension or via plugin),
only one of the two can be "the" build-parent pom.xml.

Both of those two flavors have the common parent pom-common.xml, which is copied form outside
with the plugin versions that are used by the GIB build process.